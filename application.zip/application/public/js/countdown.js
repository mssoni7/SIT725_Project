validateDate = function (e) {
  e = new Date(e);
  if ((e.getDate() <= 9) & (e.getMonth() <= 9)) {
    e =
      0 +
      e.getDate().toString() +
      "/" +
      (0 + (e.getMonth() + 1).toString()) +
      "/" +
      e.getFullYear().toString();
    return e;
  } else if ((e.getDate() > 9) & (e.getMonth() < 10)) {
    e =
      e.getDate().toString() +
      "/" +
      (0 + (e.getMonth() + 1).toString()) +
      "/" +
      e.getFullYear().toString();
    return e;
  } else if ((e.getDate() < 10) & (e.getMonth() > 9)) {
    e =
      0 +
      e.getDate().toString() +
      "/" +
      (e.getMonth() + 1).toString() +
      "/" +
      e.getFullYear().toString();
    return e;
  } else if ((e.getDate() >= 10) & (e.getMonth() >= 10)) {
    e =
      e.getDate().toString() +
      "/" +
      (e.getMonth() + 1).toString() +
      "/" +
      e.getFullYear().toString();
    return e;
  } else {
    e =
      e.getDate().toString() +
      "/" +
      (e.getMonth() + 1).toString() +
      "/" +
      e.getFullYear().toString();
    return e;
  }
};

var occasion = funtion(e);
// Update the count down every 1 second
var countdown = setInterval(function (ocassion) {
  let today = new Date();
  let occasion = new Date(
    today.getFullYear(),
    occasion.getMonth(),
    occasion.getDate()
  );
  if (today.getTime() > occasion.getTime()) {
    occasion.setFullYear(occasion.getFullYear() + 1);
  }

  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = occasion - now;

  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);

  // Display the result in the element with id="demo"
  document.getElementById("countdown").innerHTML =
    days + "d " + hours + "h " + minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("countdown").innerHTML = "EXPIRED";
  }
}, 1000);
